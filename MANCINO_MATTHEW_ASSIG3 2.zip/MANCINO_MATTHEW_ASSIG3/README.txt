Name: Matthew Mancino
Python Version: 2.7
Additional Libraries: FOLlib.py is included in the repository because of the implementation decisions
discussed in the report.pdf file.

Resources used:
  Course Textbook
  Google mostly for the definition of incremental forward Chaining
  The following URLs were used:
    http://www.lsi.upc.edu/~luigi/MTI/AI-2008-fall/07-inference-in-first-order-logic-%28us%29.ppt

Discussions:
  Fellow Classmate and we simply discussed a few ideas regarding the implementation, but didn't have any details
  involved


  ATTENTION the file FOLlib.py is necessary for the program to run! This is discussed in the report!